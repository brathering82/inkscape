- INSTALL

Put "render_scale.inx" and "render_scale.py" in your Inkscape extension directory.
On Linux:   "~/.config/inkscape/extensions/"
On Windows: "Inkscape\share\extensions\" (inside your programs folder)

- COMMENT
Tested on Inkscape 0.91
Contact me at brathering82@gmail.com

- Known bugs
	ui float precision is limited to 1
	suffix doesn't support several special chars

- Changelog
17.02.2015
	include changes made by Paul Rogalinski-Pinter
	indentation cleanup - it's all tabs now
	fixed line scale bug
10.07.2014
	updated the install packages with the changes made by Roger Jeurissen
27.06.2010
	fixed ° (degree char) in suffix
12.06.2010
	changed default circular label offset to -4.8 from 8
		- so the label will spawn above the scale
	changed INSTALL-section in README
		- added extension path for inkscape-0.47
01.12.2009
	added tabs for ui
	added circular scales

18.11.2009
	default values updated, so there is something visible after first install

17.11.2009
	initial release
